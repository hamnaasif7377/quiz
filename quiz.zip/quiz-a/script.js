// Get references to the DOM elements
const startButton = document.getElementById('start-quiz-btn');
const nextButton = document.getElementById('next-btn');
const restartButton = document.getElementById('restart-quiz-btn');
const welcomeScreen = document.getElementById('welcome-screen');
const quizScreen = document.getElementById('quiz-screen');
const resultsScreen = document.getElementById('results-screen');
const questionText = document.getElementById('question-text');
const answerButtons = document.getElementById('answer-buttons');
const scoreDisplay = document.getElementById('score');

let currentQuestionIndex, score;

// Array of quiz questions and answers
const questions = [
  {
    question: "What is the value of x if 2x = 10?",
    answers: [
      { text: "3", correct: false },
      { text: "5", correct: true },
      { text: "10", correct: false },
      { text: "15", correct: false }
    ]
  },
  {
    question: "Solve: 3x + 5 = 20. What is x?",
    answers: [
      { text: "3", correct: false },
      { text: "4", correct: false },
      { text: "5", correct: true },
      { text: "6", correct: false }
    ]
  },
  {
    question: "What is the value of y in the equation y - 3 = 7?",
    answers: [
      { text: "10", correct: true },
      { text: "7", correct: false },
      { text: "3", correct: false },
      { text: "4", correct: false }
    ]
  },
  {
    question: "If 5y = 25, what is y?",
    answers: [
      { text: "5", correct: true },
      { text: "10", correct: false },
      { text: "20", correct: false },
      { text: "25", correct: false }
    ]
  },
  {
    question: "What is the value of z in the equation 7z = 21?",
    answers: [
      { text: "1", correct: false },
      { text: "2", correct: false },
      { text: "3", correct: true },
      { text: "4", correct: false }
    ]
  }
];

// Event listener to start the quiz
startButton.addEventListener('click', startQuiz);

// Event listener for the next question button
nextButton.addEventListener('click', () => {
  currentQuestionIndex++;
  setNextQuestion();
});

// Event listener to restart the quiz
restartButton.addEventListener('click', startQuiz);

// Function to start the quiz
function startQuiz() {
  welcomeScreen.classList.add('hidden');
  resultsScreen.classList.add('hidden');
  quizScreen.classList.remove('hidden');
  currentQuestionIndex = 0;
  score = 0;
  setNextQuestion();
}

// Function to set up the next question
function setNextQuestion() {
  resetState();
  showQuestion(questions[currentQuestionIndex]);
}

// Function to display the current question and answers
function showQuestion(question) {
  questionText.innerText = question.question;
  question.answers.forEach(answer => {
    const button = document.createElement('button');
    button.innerText = answer.text;
    button.classList.add('btn');
    button.addEventListener('click', () => selectAnswer(answer));
    answerButtons.appendChild(button);
  });
}

// Function to reset the state for the next question
function resetState() {
  nextButton.classList.add('hidden');
  while (answerButtons.firstChild) {
    answerButtons.removeChild(answerButtons.firstChild);
  }
}

// Function to handle answer selection
function selectAnswer(answer) {
  if (answer.correct) {
    score++;
  }
  Array.from(answerButtons.children).forEach(button => {
    setStatusClass(button, button.innerText === answer.text && answer.correct);
  });
  if (questions.length > currentQuestionIndex + 1) {
    nextButton.classList.remove('hidden');
  } else {
    showResults();
  }
}

// Function to set the status class based on whether the answer is correct or wrong
function setStatusClass(element, correct) {
  clearStatusClass(element);
  if (correct) {
    element.classList.add('correct');
  } else {
    element.classList.add('wrong');
  }
}

// Function to clear the status class
function clearStatusClass(element) {
  element.classList.remove('correct');
  element.classList.remove('wrong');
}

// Function to show the results screen
function showResults() {
  quizScreen.classList.add('hidden');
  resultsScreen.classList.remove('hidden');
  scoreDisplay.innerText = score;
}
