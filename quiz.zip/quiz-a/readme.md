# Quiz Application

This is a single-page quiz application that presents multiple-choice questions and provides immediate feedback to users. The application is built using HTML, CSS, and JavaScript, and it demonstrates how to manage events, manipulate the DOM, and maintain application state in a web application.

## Features

- A welcome screen with a brief introduction to the quiz and a "Start Quiz" button.
- Displays one question at a time with multiple-choice answers.
- Immediate feedback indicating whether the selected answer is correct or incorrect.
- A results screen showing the user’s score and an option to retry the quiz.
- Responsive design that works well on both desktop and mobile devices.

## Structure

The project consists of three main files:

- `index.html`: Contains the HTML structure of the application.
- `styles.css`: Contains the CSS styles for the application.
- `script.js`: Contains the JavaScript code that handles the quiz logic and user interactions.

## Usage

### HTML (index.html)

The HTML file sets up the structure of the quiz application with three main sections: the welcome screen, the quiz screen, and the results screen. It includes buttons for starting the quiz, proceeding to the next question, and restarting the quiz.

### CSS (styles.css)

The CSS file styles the quiz application, making it visually engaging and responsive. It includes styles for the main container, buttons, and classes for correct and wrong answers.

### JavaScript (script.js)

The JavaScript file handles the quiz logic, including loading questions, tracking user selections, providing immediate feedback, and calculating the score. It also includes event listeners for user interactions.

## Questions

The quiz currently contains five sample multiple-choice questions related to algebra:

1. What is the value of x if 2x = 10?
2. Solve: 3x + 5 = 20. What is x?
3. What is the value of y in the equation y - 3 = 7?
4. If 5y = 25, what is y?
5. What is the value of z in the equation 7z = 21?

## How to Run

1. Clone the repository or download the project files.
2. Open the `index.html` file in a web browser.
3. Click the "Start Quiz" button to begin the quiz.
4. Answer the questions and proceed through the quiz.
5. View your score at the end and restart the quiz if desired.





